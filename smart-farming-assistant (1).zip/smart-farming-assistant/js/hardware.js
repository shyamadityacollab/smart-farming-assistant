// Hardware Architecture, BOM Cost Breakdown & Power Budget Engine
class HardwareEngine {
  constructor() {
    this.bomItems = [
      { component: "ESP32-WROOM-32 Microcontroller", role: "Central Edge MCU & State Machine", qty: 1, costInr: 320, source: "Local Electronics Hub / Robu" },
      { component: "Capacitive Soil Moisture Sensor v1.2", role: "Corrosion-resistant analog root moisture", qty: 1, costInr: 120, source: "Robu / ElectronicsComp" },
      { component: "DHT22 / SHT30 High Precision Sensor", role: "Ambient Temp, Humidity & VPD monitoring", qty: 1, costInr: 210, source: "Robu" },
      { component: "ESP32-CAM AI-Thinker Module (OV2640)", role: "Edge leaf imaging & disease diagnosis", qty: 1, costInr: 490, source: "Robu" },
      { component: "5V Optocoupler Single-Channel Relay", role: "Galvanic isolated pump switching", qty: 1, costInr: 65, source: "Local Market" },
      { component: "12V / 5V DC Submersible Water Pump", role: "Precision drip water delivery", qty: 1, costInr: 145, source: "Local Market" },
      { component: "10W Monocrystalline Solar Panel (6V)", role: "Off-grid continuous renewable power", qty: 1, costInr: 360, source: "E-Commerce" },
      { component: "18650 Li-ion Battery (2600mAh) + TP4056 BMS", role: "Buffer energy storage & charging circuit", qty: 1, costInr: 130, source: "Local Battery Store" }
    ];

    this.pinouts = [
      { pin: "GPIO 34 (ADC1_CH6)", device: "Capacitive Soil Moisture Sensor (Analog AOUT)", function: "12-bit ADC reading of soil moisture voltage (0 - 3.3V)" },
      { pin: "GPIO 4 (Digital IO)", device: "DHT22 Environmental Sensor (Data Pin)", function: "Single-bus protocol reading ambient temp & relative humidity" },
      { pin: "GPIO 26 (Digital Output)", device: "5V Relay Module (Signal IN)", function: "HIGH: Pump ON (Relay Closed) | LOW: Pump OFF (Relay Open)" },
      { pin: "GPIO 2 (Built-in LED)", device: "Status Indicator LED", function: "Heartbeat pulse, Wi-Fi sync, & fault notification" },
      { pin: "GPIO 33 (Flash / LED)", device: "ESP32-CAM Flashlight LED", function: "Illumination for crop leaf disease imaging under low light" },
      { pin: "VCC / 3.3V & 5V", device: "TP4056 Step-Up & AMS1117 3.3V LDO", function: "Regulated stable DC power rail" },
      { pin: "GND", device: "Common Ground Plane", function: "Star-grounding to eliminate analog ADC noise" }
    ];

    this.powerSpecs = {
      activeCurrentMa: 150,
      activeSeconds: 15,
      sleepCurrentUa: 15,
      sleepMinutes: 15,
      batteryCapacityMah: 2600,
      solarWattage: 10
    };
  }

  getTotalBomCost() {
    return this.bomItems.reduce((acc, item) => acc + (item.costInr * item.qty), 0);
  }

  calculatePowerMetrics() {
    const activeHrsPerDay = (24 * 60 / this.powerSpecs.sleepMinutes) * (this.powerSpecs.activeSeconds / 3600);
    const sleepHrsPerDay = 24 - activeHrsPerDay;
    
    const dailyActiveMah = activeHrsPerDay * this.powerSpecs.activeCurrentMa;
    const dailySleepMah = sleepHrsPerDay * (this.powerSpecs.sleepCurrentUa / 1000);
    const totalDailyMah = dailyActiveMah + dailySleepMah;

    const batteryDaysWithoutSun = (this.powerSpecs.batteryCapacityMah * 0.85) / totalDailyMah;

    return {
      dailyConsumptionMah: Math.round(totalDailyMah),
      batteryDaysWithoutSun: batteryDaysWithoutSun.toFixed(1),
      dailyEnergyWh: ((totalDailyMah * 3.7) / 1000).toFixed(2),
      solarRechargeHours: ((this.powerSpecs.batteryCapacityMah * 3.7 / 1000) / (this.powerSpecs.solarWattage * 0.7)).toFixed(1)
    };
  }
}

window.hardwareEngine = new HardwareEngine();
