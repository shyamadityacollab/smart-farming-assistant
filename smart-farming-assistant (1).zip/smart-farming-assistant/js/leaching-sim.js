// Root Zone Nitrate Leaching & Groundwater Protection Simulator
class LeachingSimulator {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas ? this.canvas.getContext('2d') : null;
    this.mode = 'smart'; // 'over' or 'smart'
    this.particles = [];
    this.waterLevel = 0;
    this.isRunning = false;
    this.animationId = null;
    this.leachedCount = 0;
    this.absorbedCount = 0;
    
    this.metrics = {
      waterWastedLiters: 0,
      nitrateLossKg: 0,
      financialLossInr: 0,
      groundwaterRisk: "Low (Safe)"
    };
  }

  init(canvasId) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    this.resize();
    this.resetSimulation();
  }

  resize() {
    if (!this.canvas) return;
    const rect = this.canvas.parentElement.getBoundingClientRect();
    this.canvas.width = rect.width;
    this.canvas.height = 320;
  }

  setMode(mode) {
    this.mode = mode;
    this.resetSimulation();
  }

  resetSimulation() {
    this.particles = [];
    this.leachedCount = 0;
    this.absorbedCount = 0;
    if (!this.canvas) return;

    const width = this.canvas.width;
    const rootZoneBottom = 160; // 0-160px is root zone

    // Spawn 80 Nitrate (NO3-) and nutrient particles in the root zone
    for (let i = 0; i < 80; i++) {
      this.particles.push({
        x: Math.random() * (width - 40) + 20,
        y: Math.random() * (rootZoneBottom - 40) + 40,
        vx: (Math.random() - 0.5) * 0.4,
        vy: this.mode === 'over' ? Math.random() * 1.5 + 0.8 : (Math.random() - 0.5) * 0.2,
        radius: 3.5,
        type: Math.random() > 0.3 ? 'nitrate' : 'pesticide',
        isLeached: false,
        isAbsorbed: false
      });
    }

    this.updateStats();
  }

  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.loop();
  }

  stop() {
    this.isRunning = false;
    if (this.animationId) {
      cancelAnimationFrame(this.animationId);
    }
  }

  loop() {
    if (!this.isRunning) return;
    this.update();
    this.draw();
    this.animationId = requestAnimationFrame(() => this.loop());
  }

  update() {
    if (!this.canvas) return;
    const height = this.canvas.height;
    const width = this.canvas.width;
    const rootZoneY = 160;
    const groundwaterY = 270;

    this.particles.forEach(p => {
      if (p.isLeached || p.isAbsorbed) return;

      if (this.mode === 'over') {
        // High water percolation pushes nutrients downward into deep soil and groundwater
        p.x += p.vx;
        p.y += p.vy;

        if (p.y >= groundwaterY) {
          p.isLeached = true;
          p.y = groundwaterY + Math.random() * 30;
          this.leachedCount++;
        }
      } else {
        // Precision smart irrigation: water stays in root zone; roots absorb nutrients
        p.x += p.vx;
        p.y += p.vy;

        // Bounded within root zone
        if (p.y > rootZoneY - 10) p.vy *= -1;
        if (p.y < 35) p.vy *= -1;
        if (p.x < 20 || p.x > width - 20) p.vx *= -1;

        // Gradually absorbed by root hair
        if (Math.random() < 0.005) {
          p.isAbsorbed = true;
          this.absorbedCount++;
        }
      }
    });

    this.updateStats();
  }

  updateStats() {
    if (this.mode === 'over') {
      this.metrics.waterWastedLiters = Math.min(3800, (this.leachedCount * 45));
      this.metrics.nitrateLossKg = ((this.leachedCount / 80) * 42).toFixed(1);
      this.metrics.financialLossInr = Math.round(this.metrics.nitrateLossKg * 65 + this.metrics.waterWastedLiters * 0.4);
      this.metrics.groundwaterRisk = this.leachedCount > 25 ? "CRITICAL (Severe Leaching)" : "MODERATE (Nutrient Loss)";
    } else {
      this.metrics.waterWastedLiters = 0;
      this.metrics.nitrateLossKg = "0.0";
      this.metrics.financialLossInr = 0;
      this.metrics.groundwaterRisk = "ZERO (Protected in Root Zone)";
    }

    // Emit event or update DOM elements if present
    const wastedEl = document.getElementById('statWaterWasted');
    const nitrateEl = document.getElementById('statNitrateLoss');
    const moneyEl = document.getElementById('statFinancialLoss');
    const riskEl = document.getElementById('statLeachRisk');

    if (wastedEl) wastedEl.textContent = this.mode === 'over' ? `${this.metrics.waterWastedLiters} L / acre` : "0 L (Saved)";
    if (nitrateEl) nitrateEl.textContent = this.mode === 'over' ? `${this.metrics.nitrateLossKg} kg N / acre` : "0.0 kg (Preserved)";
    if (moneyEl) moneyEl.textContent = this.mode === 'over' ? `₹ ${this.metrics.financialLossInr} lost` : "₹ 0 (100% Saved)";
    if (riskEl) {
      riskEl.textContent = this.metrics.groundwaterRisk;
      riskEl.className = this.mode === 'over' ? "text-red-400 font-bold" : "text-emerald-400 font-bold";
    }
  }

  draw() {
    if (!this.ctx || !this.canvas) return;
    const ctx = this.ctx;
    const w = this.canvas.width;
    const h = this.canvas.height;

    ctx.clearRect(0, 0, w, h);

    // Layer 1: Topsoil / Active Root Zone (0 - 160px)
    ctx.fillStyle = this.mode === 'over' ? '#1c1917' : '#292524';
    ctx.fillRect(0, 0, w, 160);

    // Layer 2: Subsoil / Vadose Zone (160 - 260px)
    ctx.fillStyle = this.mode === 'over' ? '#292524' : '#1c1917';
    ctx.fillRect(0, 160, w, 100);

    // Layer 3: Groundwater Aquifer (> 260px)
    ctx.fillStyle = this.mode === 'over' ? '#1e3a5f' : '#0f172a';
    ctx.fillRect(0, 260, w, h - 260);

    // Layer Divider Lines & Labels
    ctx.strokeStyle = '#44403c';
    ctx.lineWidth = 1.5;
    ctx.beginPath();
    ctx.moveTo(0, 160); ctx.lineTo(w, 160);
    ctx.moveTo(0, 260); ctx.lineTo(w, 260);
    ctx.stroke();

    ctx.font = '11px sans-serif';
    ctx.fillStyle = '#a8a29e';
    ctx.fillText('🌱 ACTIVE ROOT ZONE (0 - 30 cm) - Plant Roots & Nutrients', 14, 22);
    ctx.fillText('🪨 SUBSOIL / LEACHING ZONE (30 - 60 cm)', 14, 180);
    ctx.fillStyle = this.mode === 'over' ? '#93c5fd' : '#64748b';
    ctx.fillText('💧 GROUNDWATER TABLE & CANAL WATERWAYS (> 60 cm)', 14, 280);

    // Draw Plant Stem and Root System in Root Zone
    this.drawRoots(ctx, w / 2, 0);

    // Draw Moving Water Flow Lines
    if (this.mode === 'over') {
      ctx.strokeStyle = 'rgba(56, 189, 248, 0.4)';
      ctx.lineWidth = 2;
      ctx.setLineDash([6, 6]);
      for (let x = 40; x < w; x += 60) {
        ctx.beginPath();
        ctx.moveTo(x, 10);
        ctx.lineTo(x, h - 10);
        ctx.stroke();
      }
      ctx.setLineDash([]);
    }

    // Draw Nutrient / Nitrate Particles
    this.particles.forEach(p => {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      if (p.type === 'nitrate') {
        ctx.fillStyle = p.isLeached ? '#ef4444' : '#38bdf8'; // Blue in root zone, Red when contaminated in groundwater
      } else {
        ctx.fillStyle = p.isLeached ? '#dc2626' : '#a855f7'; // Purple pesticide residue
      }
      ctx.fill();
    });

    // Draw Over-irrigation warning text on canvas
    if (this.mode === 'over' && this.leachedCount > 15) {
      ctx.fillStyle = 'rgba(239, 68, 68, 0.9)';
      ctx.fillRect(w - 240, 10, 230, 36);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText('⚠️ EXCESSIVE IRRIGATION DETECTED', w - 230, 25);
      ctx.font = '10px sans-serif';
      ctx.fillText('Fertilizer leaching into aquifer!', w - 230, 38);
    } else if (this.mode === 'smart') {
      ctx.fillStyle = 'rgba(16, 185, 129, 0.9)';
      ctx.fillRect(w - 240, 10, 230, 36);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 11px sans-serif';
      ctx.fillText('✅ PRECISION IRRIGATION ACTIVE', w - 230, 25);
      ctx.font = '10px sans-serif';
      ctx.fillText('100% Nutrients retained in root zone', w - 230, 38);
    }
  }

  drawRoots(ctx, centerX, topY) {
    ctx.strokeStyle = '#eab308';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.moveTo(centerX, topY);
    ctx.lineTo(centerX, topY + 40);
    
    // Primary branches
    ctx.lineTo(centerX - 50, topY + 90);
    ctx.moveTo(centerX, topY + 40);
    ctx.lineTo(centerX + 60, topY + 85);
    ctx.moveTo(centerX, topY + 40);
    ctx.lineTo(centerX, topY + 120);

    // Fine root hairs
    ctx.lineWidth = 1.5;
    ctx.moveTo(centerX - 50, topY + 90); ctx.lineTo(centerX - 90, topY + 130);
    ctx.moveTo(centerX - 50, topY + 90); ctx.lineTo(centerX - 30, topY + 140);
    ctx.moveTo(centerX + 60, topY + 85); ctx.lineTo(centerX + 110, topY + 125);
    ctx.moveTo(centerX + 60, topY + 85); ctx.lineTo(centerX + 40, topY + 145);
    ctx.moveTo(centerX, topY + 120); ctx.lineTo(centerX - 20, topY + 155);
    ctx.moveTo(centerX, topY + 120); ctx.lineTo(centerX + 25, topY + 155);
    ctx.stroke();

    // Plant foliage top
    ctx.fillStyle = '#22c55e';
    ctx.beginPath();
    ctx.arc(centerX, topY, 16, 0, Math.PI, true);
    ctx.fill();
  }
}

window.leachingSimulator = new LeachingSimulator('leachingCanvas');
