// Main Application Controller, Sensor Advisory Coordinator & UI Events
class App {
  constructor() {
    this.currentLang = 'en';
    this.activeTab = 'dashboard';
    this.isSpeaking = false;
    this.searchDebounceTimer = null;
  }

  async init() {
    // 1. Initialize Core Engines
    await window.weatherEngine.fetchForecast("Ludhiana, Punjab");
    window.telemetryEngine.initChart('telemetryChart');
    window.leachingSimulator.init('leachingCanvas');
    window.leachingSimulator.start();

    // 2. Setup Navigation and UI Handlers
    this.setupNavigation();
    this.setupLanguageSwitcher();
    this.setupSimulationControls();
    this.setupVisionStudio();
    this.setupWeatherControls();
    this.setupSensorInputPortal();
    this.setupHardwareView();
    this.setupVoiceAssistant();

    // 3. Render Initial State
    this.applyTranslations(this.currentLang);
    this.renderCategoryFilter("all");
    this.selectVisionSample("tomato_late_blight");
    this.renderWeatherUI();
    this.renderHardwareUI();
    this.triggerDefaultSensorAdvisory();
  }

  setupNavigation() {
    const navButtons = document.querySelectorAll('[data-tab-target]');
    navButtons.forEach(btn => {
      btn.addEventListener('click', (e) => {
        const target = btn.getAttribute('data-tab-target');
        this.switchTab(target);
      });
    });
  }

  switchTab(tabId) {
    this.activeTab = tabId;
    
    document.querySelectorAll('[data-tab-target]').forEach(btn => {
      if (btn.getAttribute('data-tab-target') === tabId) {
        btn.classList.add('bg-emerald-600', 'text-white', 'shadow-lg');
        btn.classList.remove('text-slate-400', 'hover:text-slate-200', 'hover:bg-slate-800');
      } else {
        btn.classList.remove('bg-emerald-600', 'text-white', 'shadow-lg');
        btn.classList.add('text-slate-400', 'hover:text-slate-200', 'hover:bg-slate-800');
      }
    });

    document.querySelectorAll('.tab-panel').forEach(panel => {
      if (panel.id === `tab-${tabId}`) {
        panel.classList.remove('hidden');
      } else {
        panel.classList.add('hidden');
      }
    });

    if (tabId === 'dashboard' && window.telemetryEngine.chart) {
      window.telemetryEngine.chart.resize();
    }
    if (tabId === 'leaching' && window.leachingSimulator) {
      window.leachingSimulator.resize();
      window.leachingSimulator.resetSimulation();
    }
  }

  setupLanguageSwitcher() {
    const langSelect = document.getElementById('langSelect');
    if (!langSelect) return;

    langSelect.addEventListener('change', (e) => {
      this.currentLang = e.target.value;
      this.applyTranslations(this.currentLang);
    });
  }

  applyTranslations(lang) {
    const dict = translations[lang] || translations.en;
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (dict[key]) {
        el.textContent = dict[key];
      }
    });
  }

  setupSimulationControls() {
    const sliderMoisture = document.getElementById('sliderMoisture');
    const sliderLabel = document.getElementById('sliderMoistureVal');
    const selectCrop = document.getElementById('selectCrop');
    const selectSoil = document.getElementById('selectSoil');
    const toggleRain = document.getElementById('toggleRainSim');

    if (sliderMoisture) {
      sliderMoisture.addEventListener('input', (e) => {
        const val = parseFloat(e.target.value);
        window.telemetryEngine.soilMoisture = val;
        if (sliderLabel) sliderLabel.textContent = `${val}%`;
        window.telemetryEngine.tick();
      });
    }

    if (selectSoil) {
      selectSoil.addEventListener('change', (e) => {
        const soil = window.telemetryEngine.soilProfiles[e.target.value];
        if (soil) {
          window.telemetryEngine.customThreshold = soil.defaultThreshold;
          const threshEl = document.getElementById('dispThreshold');
          if (threshEl) threshEl.textContent = `${soil.defaultThreshold}%`;
          window.telemetryEngine.tick();
        }
      });
    }

    if (selectCrop) {
      selectCrop.addEventListener('change', (e) => {
        const crop = window.telemetryEngine.cropProfiles[e.target.value];
        if (crop) {
          const vpdReqEl = document.getElementById('dispVpdReq');
          if (vpdReqEl) vpdReqEl.textContent = crop.vpdRange;
        }
      });
    }

    if (toggleRain) {
      toggleRain.addEventListener('change', (e) => {
        if (window.weatherEngine.weatherData) {
          window.weatherEngine.weatherData.isRainImminent = e.target.checked;
          window.weatherEngine.weatherData.rainProb6h = e.target.checked ? 85 : 10;
          this.renderWeatherUI();
          window.telemetryEngine.tick();
        }
      });
    }

    const btnOver = document.getElementById('btnSimOver');
    const btnSmart = document.getElementById('btnSimSmart');

    if (btnOver) {
      btnOver.addEventListener('click', () => {
        window.leachingSimulator.setMode('over');
        btnOver.classList.add('bg-red-600', 'text-white');
        btnOver.classList.remove('bg-slate-800', 'text-slate-300');
        btnSmart.classList.remove('bg-emerald-600', 'text-white');
        btnSmart.classList.add('bg-slate-800', 'text-slate-300');
      });
    }

    if (btnSmart) {
      btnSmart.addEventListener('click', () => {
        window.leachingSimulator.setMode('smart');
        btnSmart.classList.add('bg-emerald-600', 'text-white');
        btnSmart.classList.remove('bg-slate-800', 'text-slate-300');
        btnOver.classList.remove('bg-red-600', 'text-white');
        btnOver.classList.add('bg-slate-800', 'text-slate-300');
      });
    }
  }

  setupVisionStudio() {
    const fileUpload = document.getElementById('leafImageInput');
    if (fileUpload) {
      fileUpload.addEventListener('change', (e) => {
        const file = e.target.files[0];
        if (file) {
          const reader = new FileReader();
          reader.onload = (event) => {
            const img = new Image();
            img.onload = () => {
              this.executeCustomImageScanning(img, event.target.result);
            };
            img.src = event.target.result;
          };
          reader.readAsDataURL(file);
        }
      });
    }

    document.querySelectorAll('[data-vision-cat]').forEach(btn => {
      btn.addEventListener('click', () => {
        const cat = btn.getAttribute('data-vision-cat');
        document.querySelectorAll('[data-vision-cat]').forEach(b => {
          b.classList.remove('bg-emerald-600', 'text-white');
          b.classList.add('bg-slate-800', 'text-slate-400');
        });
        btn.classList.add('bg-emerald-600', 'text-white');
        btn.classList.remove('bg-slate-800', 'text-slate-400');
        this.renderCategoryFilter(cat);
      });
    });
  }

  executeCustomImageScanning(imgElement, dataUrl) {
    const preview = document.getElementById('leafPreviewContainer');
    if (!preview) return;

    preview.innerHTML = `
      <div class="relative w-full h-48 rounded-xl overflow-hidden border-2 border-emerald-500 bg-black">
        <img src="${dataUrl}" class="w-full h-full object-cover opacity-80" />
        <div class="absolute inset-0 bg-gradient-to-b from-transparent via-emerald-400/40 to-transparent animate-water-flow h-12 w-full"></div>
        <div class="absolute bottom-2 left-2 px-3 py-1 rounded bg-black/80 text-emerald-400 text-xs font-mono font-bold flex items-center gap-2">
          <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span> Deep Scanning Pixel Spectrum...
        </div>
      </div>
    `;

    setTimeout(() => {
      const match = window.aiVisionStudio.analyzeUploadedImage(imgElement);
      this.populateVisionDiagnosis(match);
      preview.innerHTML = `
        <div class="relative w-full h-48 rounded-xl overflow-hidden border-2 border-emerald-500">
          <img src="${dataUrl}" class="w-full h-full object-cover" />
          <div class="absolute top-2 right-2 px-2.5 py-1 rounded-full bg-emerald-950 text-emerald-300 text-xs font-bold border border-emerald-700">
            ${match.confidence}% Match
          </div>
        </div>
      `;
    }, 1500);
  }

  renderCategoryFilter(category) {
    const container = document.getElementById('sampleLeafContainer');
    if (!container) return;

    const filtered = window.aiVisionStudio.filterCategory(category);
    container.innerHTML = filtered.map(s => `
      <button onclick="window.app.selectVisionSample('${s.id}')" class="p-3 rounded-lg bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-left transition-all flex items-center justify-between group">
        <div>
          <div class="font-semibold text-sm text-slate-200 group-hover:text-emerald-400">${s.condition.split('(')[0]}</div>
          <div class="text-xs text-slate-400">${s.crop.split('(')[0]}</div>
        </div>
        <span class="text-xs px-2 py-0.5 rounded-full ${s.badgeClass}">${s.type}</span>
      </button>
    `).join('');
  }

  selectVisionSample(id) {
    const sample = window.aiVisionStudio.getSampleById(id);
    if (!sample) return;

    const previewContainer = document.getElementById('leafPreviewContainer');
    if (previewContainer) {
      previewContainer.innerHTML = window.aiVisionStudio.generateLeafSvg(sample);
    }
    this.populateVisionDiagnosis(sample);
  }

  populateVisionDiagnosis(sample) {
    const titleEl = document.getElementById('resDiseaseTitle');
    const cropEl = document.getElementById('resCropName');
    const confEl = document.getElementById('resConfidence');
    const confBarEl = document.getElementById('resConfidenceBar');
    const severityEl = document.getElementById('resSeverity');
    const symptomsEl = document.getElementById('resSymptomsList');
    const organicEl = document.getElementById('resOrganicText');
    const chemicalEl = document.getElementById('resChemicalText');
    const leachingEl = document.getElementById('resLeachingText');

    if (titleEl) titleEl.textContent = sample.condition;
    if (cropEl) cropEl.textContent = sample.crop;
    if (confEl) confEl.textContent = `${sample.confidence}%`;
    if (confBarEl) confBarEl.style.width = `${sample.confidence}%`;
    if (severityEl) {
      severityEl.textContent = sample.severity;
      severityEl.className = `text-xs font-bold px-2.5 py-0.5 rounded-full ${sample.badgeClass}`;
    }

    if (symptomsEl) {
      symptomsEl.innerHTML = sample.symptoms.map(s => `<li class="flex items-start gap-2"><span class="text-emerald-400">✔</span><span>${s}</span></li>`).join('');
    }

    if (organicEl) organicEl.textContent = sample.organicTreatment;
    if (chemicalEl) chemicalEl.textContent = sample.chemicalTreatment;
    if (leachingEl) leachingEl.textContent = sample.runoffWarning;
  }

  // Weather & Universal Location Search Controls
  setupWeatherControls() {
    const searchInput = document.getElementById('locationSearchInput');
    const searchResultsDropdown = document.getElementById('locationSearchResults');
    const btnGps = document.getElementById('btnDetectGps');

    // 1. Live Geocoding Search Input with Debouncing
    if (searchInput && searchResultsDropdown) {
      searchInput.addEventListener('input', (e) => {
        const query = e.target.value.trim();
        clearTimeout(this.searchDebounceTimer);

        if (query.length < 2) {
          searchResultsDropdown.classList.add('hidden');
          return;
        }

        this.searchDebounceTimer = setTimeout(async () => {
          const results = await window.weatherEngine.searchAnyLocation(query);
          this.renderLocationSearchResults(results);
        }, 300);
      });

      // Close dropdown when clicking outside
      document.addEventListener('click', (e) => {
        if (!searchInput.contains(e.target) && !searchResultsDropdown.contains(e.target)) {
          searchResultsDropdown.classList.add('hidden');
        }
      });
    }

    // 2. Live GPS Button
    if (btnGps) {
      btnGps.addEventListener('click', async () => {
        btnGps.innerHTML = `⏳ <span>Detecting GPS Location...</span>`;
        await window.weatherEngine.detectUserGpsLocation();
        btnGps.innerHTML = `📍 <span>Detected: ${window.weatherEngine.currentCity.substring(0, 22)}...</span>`;
        this.renderWeatherUI();
        window.telemetryEngine.tick();
      });
    }

    // 3. Render Preset Location Chips
    const presetContainer = document.getElementById('presetLocationChips');
    if (presetContainer) {
      presetContainer.innerHTML = window.weatherEngine.popularPresets.map(p => `
        <button onclick="window.app.selectPresetLocation('${p.lat}', '${p.lon}', '${p.name}')" class="px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-emerald-950 text-slate-300 hover:text-emerald-300 border border-slate-700 text-xs font-semibold transition-all">
          ${p.name.split(',')[0]}
        </button>
      `).join('');
    }
  }

  renderLocationSearchResults(results) {
    const dropdown = document.getElementById('locationSearchResults');
    if (!dropdown) return;

    if (!results || results.length === 0) {
      dropdown.innerHTML = `<div class="p-3 text-xs text-slate-400">No matching locations found. Try another city or district name.</div>`;
      dropdown.classList.remove('hidden');
      return;
    }

    dropdown.innerHTML = results.map(r => `
      <div onclick="window.app.selectPresetLocation('${r.lat}', '${r.lon}', '${r.displayName.replace(/'/g, "\\'")}')" class="p-2.5 hover:bg-slate-800 border-b border-slate-800 last:border-0 cursor-pointer flex items-center justify-between text-xs transition-all">
        <div>
          <span class="font-bold text-slate-100">${r.name}</span>
          <span class="text-slate-400 ml-1">${r.admin1 ? r.admin1 + ', ' : ''}${r.country}</span>
        </div>
        <span class="text-[10px] font-mono text-emerald-400">${r.lat.toFixed(2)}°, ${r.lon.toFixed(2)}°</span>
      </div>
    `).join('');

    dropdown.classList.remove('hidden');
  }

  async selectPresetLocation(lat, lon, displayName) {
    const dropdown = document.getElementById('locationSearchResults');
    const searchInput = document.getElementById('locationSearchInput');
    if (dropdown) dropdown.classList.add('hidden');
    if (searchInput) searchInput.value = displayName;

    await window.weatherEngine.fetchForecastByCoords(parseFloat(lat), parseFloat(lon), displayName);
    this.renderWeatherUI();
    window.telemetryEngine.tick();
  }

  renderWeatherUI() {
    const w = window.weatherEngine.weatherData;
    if (!w) return;

    const cityEl = document.getElementById('dispWeatherCity');
    const tempEl = document.getElementById('dispWeatherTemp');
    const condEl = document.getElementById('dispWeatherCond');
    const rainProbEl = document.getElementById('dispWeatherRainProb');
    const decisionEl = document.getElementById('dispWeatherDecision');
    const sixHourContainer = document.getElementById('dispSixHourSlices');
    const anomalyContainer = document.getElementById('dispAnomalyRadar');
    const coordsEl = document.getElementById('dispCoords');

    if (cityEl) cityEl.textContent = w.cityName;
    if (tempEl) tempEl.textContent = `${w.temp}°C`;
    if (condEl) condEl.textContent = w.conditionText;
    if (rainProbEl) rainProbEl.textContent = `${w.rainProb6h}%`;
    if (coordsEl) coordsEl.textContent = `${window.weatherEngine.lat.toFixed(3)}°N, ${window.weatherEngine.lon.toFixed(3)}°E`;

    if (decisionEl) {
      if (w.isRainImminent) {
        decisionEl.innerHTML = `
          <div class="p-4 rounded-xl bg-amber-950/60 border border-amber-600/60 text-amber-200 flex items-start gap-3">
            <span class="text-2xl">⏳</span>
            <div>
              <div class="font-bold text-base">Predictive Rain Delay Activated</div>
              <div class="text-xs mt-1 text-amber-300">Precipitation expected in next 6 hours (${w.rainSum6h} mm). System will <strong>HOLD irrigation</strong> to save power, conserve fresh water, and prevent fertilizer leaching into groundwater.</div>
            </div>
          </div>
        `;
      } else {
        decisionEl.innerHTML = `
          <div class="p-4 rounded-xl bg-emerald-950/60 border border-emerald-600/60 text-emerald-200 flex items-start gap-3">
            <span class="text-2xl">⚡</span>
            <div>
              <div class="font-bold text-base">Clear Weather - Standard IoT Autonomy</div>
              <div class="text-xs mt-1 text-emerald-300">No rain forecasted. Irrigation pump will trigger automatically only when soil moisture drops below calibrated target (${window.telemetryEngine.customThreshold}%).</div>
            </div>
          </div>
        `;
      }
    }

    if (sixHourContainer && w.sixHourSlices) {
      sixHourContainer.innerHTML = w.sixHourSlices.map(s => `
        <div class="p-3.5 rounded-xl ${s.isRainy ? 'bg-sky-950/60 border-sky-700' : 'bg-slate-900/80 border-slate-800'} border flex flex-col justify-between space-y-2">
          <div class="flex justify-between items-center text-xs">
            <span class="font-bold text-slate-200">${s.intervalLabel}</span>
            <span class="text-[10px] text-slate-400">${s.timeRange}</span>
          </div>
          <div class="flex items-baseline justify-between">
            <span class="text-lg font-black text-white">${s.maxTemp}°C</span>
            <span class="text-xs font-semibold ${s.maxRainProb >= 50 ? 'text-sky-400 font-bold' : 'text-slate-400'}">💧 ${s.maxRainProb}%</span>
          </div>
          <div class="text-[11px] text-slate-400 flex justify-between pt-1 border-t border-slate-800">
            <span>Rain: ${s.totalRainMm}mm</span>
            <span>RH: ${s.avgHumidity}%</span>
          </div>
        </div>
      `).join('');
    }

    if (anomalyContainer && window.weatherEngine.anomalies) {
      anomalyContainer.innerHTML = window.weatherEngine.anomalies.map(a => `
        <div class="p-3.5 rounded-xl ${a.badgeClass} border flex items-start gap-3">
          <div class="space-y-1">
            <div class="flex items-center gap-2">
              <span class="font-bold text-sm">${a.title}</span>
              <span class="text-[10px] px-2 py-0.5 rounded font-black tracking-wider uppercase bg-black/40">${a.level}</span>
            </div>
            <p class="text-xs leading-relaxed opacity-90">${a.desc}</p>
          </div>
        </div>
      `).join('');
    }
  }

  setupSensorInputPortal() {
    const btnSubmit = document.getElementById('btnSubmitSensorReadings');
    if (btnSubmit) {
      btnSubmit.addEventListener('click', () => {
        this.processSensorInputAdvisory();
      });
    }

    const btnDrought = document.getElementById('presetDrought');
    const btnFungal = document.getElementById('presetFungal');
    const btnOptimal = document.getElementById('presetOptimal');
    const btnPreRain = document.getElementById('presetPreRain');

    if (btnDrought) {
      btnDrought.addEventListener('click', () => {
        this.fillSensorForm(14, 41.5, 26, 34, "Tomato / Vegetables", "Flowering Stage", "Sandy Soil");
        this.processSensorInputAdvisory();
      });
    }

    if (btnFungal) {
      btnFungal.addEventListener('click', () => {
        this.fillSensorForm(44, 27.0, 88, 24, "Paddy / Rice", "Vegetative Stage", "Clay / Black Soil");
        this.processSensorInputAdvisory();
      });
    }

    if (btnOptimal) {
      btnOptimal.addEventListener('click', () => {
        this.fillSensorForm(38, 29.0, 58, 26, "Wheat", "Fruiting / Grain Fill", "Loamy Soil");
        this.processSensorInputAdvisory();
      });
    }

    if (btnPreRain) {
      btnPreRain.addEventListener('click', () => {
        this.fillSensorForm(18, 32.0, 72, 28, "Cotton", "Vegetative Stage", "Loamy Soil");
        if (window.weatherEngine.weatherData) {
          window.weatherEngine.weatherData.isRainImminent = true;
          window.weatherEngine.weatherData.rainProb6h = 85;
        }
        this.processSensorInputAdvisory();
      });
    }
  }

  fillSensorForm(moisture, temp, humidity, soilTemp, crop, stage, soilType) {
    const elM = document.getElementById('inMoisture');
    const elT = document.getElementById('inTemp');
    const elH = document.getElementById('inHumidity');
    const elST = document.getElementById('inSoilTemp');
    const elCrop = document.getElementById('inCrop');
    const elStage = document.getElementById('inStage');
    const elSoil = document.getElementById('inSoil');

    if (elM) elM.value = moisture;
    if (elT) elT.value = temp;
    if (elH) elH.value = humidity;
    if (elST) elST.value = soilTemp;
    if (elCrop) elCrop.value = crop;
    if (elStage) elStage.value = stage;
    if (elSoil) elSoil.value = soilType;
  }

  triggerDefaultSensorAdvisory() {
    this.fillSensorForm(22, 34.5, 48, 29, "Tomato / Vegetables", "Flowering Stage", "Loamy Soil");
    this.processSensorInputAdvisory();
  }

  processSensorInputAdvisory() {
    const elM = document.getElementById('inMoisture');
    const elT = document.getElementById('inTemp');
    const elH = document.getElementById('inHumidity');
    const elST = document.getElementById('inSoilTemp');
    const elCrop = document.getElementById('inCrop');
    const elStage = document.getElementById('inStage');
    const elSoil = document.getElementById('inSoil');

    const inputs = {
      moisture: parseFloat(elM ? elM.value : 25),
      temp: parseFloat(elT ? elT.value : 30),
      humidity: parseFloat(elH ? elH.value : 55),
      soilTemp: parseFloat(elST ? elST.value : 26),
      crop: elCrop ? elCrop.value : "Tomato / Vegetables",
      stage: elStage ? elStage.value : "Flowering Stage",
      soilType: elSoil ? elSoil.value : "Loamy Soil"
    };

    const adv = window.telemetryEngine.generateManualAdvisory(inputs);

    const statusEl = document.getElementById('advIrrigationStatus');
    const runtimeEl = document.getElementById('advPumpRuntime');
    const volumeEl = document.getElementById('advWaterVolume');
    const recTextEl = document.getElementById('advRecommendationText');
    const vpdEl = document.getElementById('advVpdValue');
    const vpdStatusEl = document.getElementById('advVpdStatus');
    const diseaseRiskEl = document.getElementById('advDiseaseRisk');
    const diseaseAdviceEl = document.getElementById('advDiseaseAdvice');
    const leachingEl = document.getElementById('advLeachingHazard');

    if (statusEl) {
      statusEl.textContent = adv.irrigationStatus;
      if (adv.irrigationStatus.includes("CRITICAL")) {
        statusEl.className = "px-3.5 py-1.5 rounded-full text-xs font-bold bg-red-950 text-red-300 border border-red-700 animate-pulse";
      } else if (adv.irrigationStatus.includes("DELAYED")) {
        statusEl.className = "px-3.5 py-1.5 rounded-full text-xs font-bold bg-amber-950 text-amber-300 border border-amber-700";
      } else {
        statusEl.className = "px-3.5 py-1.5 rounded-full text-xs font-bold bg-emerald-950 text-emerald-300 border border-emerald-700";
      }
    }

    if (runtimeEl) runtimeEl.textContent = `${adv.pumpMinutes} Mins`;
    if (volumeEl) volumeEl.textContent = `${adv.waterLitersPerAcre.toLocaleString()} L/acre`;
    if (recTextEl) recTextEl.innerHTML = adv.recommendation;

    if (vpdEl) vpdEl.textContent = `${adv.vpd} kPa`;
    if (vpdStatusEl) {
      vpdStatusEl.textContent = adv.vpdStatus;
      vpdStatusEl.className = `text-xs font-semibold ${adv.vpdColor}`;
    }

    if (diseaseRiskEl) {
      diseaseRiskEl.textContent = adv.diseaseRisk;
      diseaseRiskEl.className = `text-xs font-bold ${adv.diseaseRiskColor}`;
    }
    if (diseaseAdviceEl) diseaseAdviceEl.textContent = adv.diseaseAdvice;

    if (leachingEl) {
      leachingEl.textContent = adv.leachingHazard;
      leachingEl.className = `text-xs font-bold ${adv.leachingColor}`;
    }
  }

  setupHardwareView() {
    const bomTable = document.getElementById('bomTableBody');
    if (!bomTable) return;

    bomTable.innerHTML = window.hardwareEngine.bomItems.map(item => `
      <tr class="border-b border-slate-800 hover:bg-slate-800/40">
        <td class="py-3 px-4 text-slate-200 font-medium">${item.component}</td>
        <td class="py-3 px-4 text-slate-400 text-xs">${item.role}</td>
        <td class="py-3 px-4 text-center text-slate-300">${item.qty}</td>
        <td class="py-3 px-4 text-right text-emerald-400 font-bold">₹ ${item.costInr}</td>
      </tr>
    `).join('');

    const totalEl = document.getElementById('bomTotalCost');
    if (totalEl) totalEl.textContent = `₹ ${window.hardwareEngine.getTotalBomCost()} INR`;

    const pinoutList = document.getElementById('pinoutList');
    if (pinoutList) {
      pinoutList.innerHTML = window.hardwareEngine.pinouts.map(p => `
        <div class="p-3 rounded-lg bg-slate-800/60 border border-slate-700 flex flex-col md:flex-row md:items-center justify-between gap-2">
          <div class="flex items-center gap-2">
            <span class="px-2.5 py-1 rounded bg-emerald-950 text-emerald-300 font-mono text-xs border border-emerald-800">${p.pin}</span>
            <span class="font-semibold text-sm text-slate-200">${p.device}</span>
          </div>
          <div class="text-xs text-slate-400">${p.function}</div>
        </div>
      `).join('');
    }
  }

  renderHardwareUI() {
    const powerMetrics = window.hardwareEngine.calculatePowerMetrics();
    const batteryDaysEl = document.getElementById('statBatteryDays');
    const dailyMahEl = document.getElementById('statDailyMah');
    const rechargeEl = document.getElementById('statRechargeHrs');

    if (batteryDaysEl) batteryDaysEl.textContent = `${powerMetrics.batteryDaysWithoutSun} Days`;
    if (dailyMahEl) dailyMahEl.textContent = `${powerMetrics.dailyConsumptionMah} mAh`;
    if (rechargeEl) rechargeEl.textContent = `${powerMetrics.solarRechargeHours} hrs`;
  }

  setupVoiceAssistant() {
    const voiceBtn = document.getElementById('btnVoiceAdvisory');
    if (!voiceBtn) return;

    voiceBtn.addEventListener('click', () => {
      this.playVoiceAdvisory();
    });
  }

  playVoiceAdvisory() {
    if (!('speechSynthesis' in window)) {
      alert("Text-to-speech not supported in this browser.");
      return;
    }

    if (this.isSpeaking) {
      window.speechSynthesis.cancel();
      this.isSpeaking = false;
      const btn = document.getElementById('btnVoiceAdvisory');
      if (btn) btn.innerHTML = `🔊 <span data-i18n="listenAdvisory">Listen to Voice Advisory</span>`;
      return;
    }

    const moisture = window.telemetryEngine.soilMoisture.toFixed(0);
    const pumpState = window.telemetryEngine.pumpState;
    const rainProb = window.weatherEngine.weatherData ? window.weatherEngine.weatherData.rainProb6h : 60;

    let text = "";
    let voiceLang = "en-IN";

    if (this.currentLang === 'hi') {
      voiceLang = "hi-IN";
      text = `किसान भाई नमस्ते। आपके खेत में मिट्टी की नमी ${moisture} प्रतिशत है। अगले छह घंटों में ${rainProb} प्रतिशत बारिश की संभावना है। हमारी प्रणाली ने पानी और खाद बचाने के लिए सिंचाई को स्थगित रखा है।`;
    } else if (this.currentLang === 'pb') {
      voiceLang = "pa-IN";
      text = `ਸਤਿ ਸ੍ਰੀ ਅਕਾਲ ਕਿਸਾਨ ਵੀਰੋ। ਤੁਹਾਡੇ ਖੇਤ ਵਿੱਚ ਮਿੱਟੀ ਦੀ ਨਮੀ ${moisture} ਫ਼ੀਸਦੀ ਹੈ। ਅਗਲੇ ਛੇ ਘੰਟਿਆਂ ਵਿੱਚ ਮੀਂਹ ਦੀ ਸੰਭਾਵਨਾ ਹੈ।`;
    } else {
      voiceLang = "en-IN";
      text = `Farmer advisory alert. Soil moisture is at ${moisture} percent. Six-hour rainfall probability is ${rainProb} percent. Pump status is ${pumpState}. All root zone nutrients are securely retained.`;
    }

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = voiceLang;
    utterance.rate = 0.95;

    const btn = document.getElementById('btnVoiceAdvisory');
    if (btn) btn.innerHTML = `⏹️ <span>Playing Advisory...</span>`;

    utterance.onend = () => {
      this.isSpeaking = false;
      if (btn) btn.innerHTML = `🔊 <span data-i18n="listenAdvisory">Listen to Voice Advisory</span>`;
    };

    this.isSpeaking = true;
    window.speechSynthesis.speak(utterance);
  }
}

window.app = new App();
document.addEventListener('DOMContentLoaded', () => {
  window.app.init();
});
