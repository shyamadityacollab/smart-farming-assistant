// Live IoT Sensor Telemetry & AI Farm Brain Decision Matrix Engine
class TelemetryEngine {
  constructor() {
    this.mode = "simulation";
    this.soilMoisture = 28;
    this.ambientTemp = 31.5;
    this.humidity = 58;
    this.vpd = 1.95;
    this.heatIndex = 34.2;
    
    this.crop = "Tomato / Vegetables";
    this.soil = "Loamy Soil";
    this.customThreshold = 38;

    this.pumpState = "IDLE";
    this.pumpReason = "Moisture within optimal range";
    this.pumpActiveSeconds = 0;
    
    this.stats = {
      waterSavedLiters: 1450,
      energySavedWh: 820,
      fertilizerSavedKg: 18.5
    };

    this.history = {
      labels: [],
      moisture: [],
      temp: [],
      vpd: []
    };

    this.chart = null;
    this.timer = null;

    this.soilProfiles = {
      "Sandy Soil": { fc: 18, pwp: 6, defaultThreshold: 22, rootDepthMm: 250, name: "Sandy Soil (High Drainage)" },
      "Loamy Soil": { fc: 32, pwp: 14, defaultThreshold: 36, rootDepthMm: 350, name: "Loamy Soil (Balanced)" },
      "Clay / Black Soil": { fc: 48, pwp: 24, defaultThreshold: 50, rootDepthMm: 450, name: "Clay / Black Cotton Soil" }
    };

    this.cropProfiles = {
      "Tomato / Vegetables": { moistureReq: 42, vpdRange: "0.8 - 1.4 kPa", waterFactor: 1.2 },
      "Paddy / Rice": { moistureReq: 65, vpdRange: "0.5 - 1.1 kPa", waterFactor: 2.0 },
      "Wheat": { moistureReq: 35, vpdRange: "1.0 - 1.6 kPa", waterFactor: 0.9 },
      "Cotton": { moistureReq: 32, vpdRange: "1.2 - 2.0 kPa", waterFactor: 0.85 },
      "Sugarcane": { moistureReq: 55, vpdRange: "0.8 - 1.5 kPa", waterFactor: 1.8 }
    };
  }

  // AI Farm Brain: Multi-Factor Agricultural Decision Generator
  generateManualAdvisory(inputs) {
    const { moisture, temp, humidity, soilTemp, crop, stage, soilType } = inputs;

    // 1. Calculate Vapor Pressure Deficit (VPD in kPa)
    const es = 0.61078 * Math.exp((17.27 * temp) / (temp + 237.3));
    const ea = es * (humidity / 100);
    const vpd = Math.max(0.1, parseFloat((es - ea).toFixed(2)));

    // 2. VPD Transpiration Health
    let vpdStatus = "Optimal Transpiration";
    let vpdColor = "text-emerald-400";
    if (vpd < 0.5) {
      vpdStatus = "Under-Transpiring (Excess Humidity - High Disease Risk)";
      vpdColor = "text-amber-400";
    } else if (vpd > 2.2) {
      vpdStatus = "Severe Transpiration Stress (Stomata Closing / Wilting)";
      vpdColor = "text-red-400";
    }

    // 3. Soil Water Deficit & Irrigation Volume Calculation
    const soilInfo = this.soilProfiles[soilType] || this.soilProfiles["Loamy Soil"];
    const cropInfo = this.cropProfiles[crop] || this.cropProfiles["Tomato / Vegetables"];
    const targetMoisture = cropInfo.moistureReq;
    const moistureDeficit = Math.max(0, targetMoisture - moisture);

    // Weather predictive factor
    const rainForecast = window.weatherEngine && window.weatherEngine.weatherData ? window.weatherEngine.weatherData.rainProb6h : 20;
    const isRainImminent = rainForecast >= 50;

    let irrigationStatus = "OPTIMAL";
    let pumpMinutes = 0;
    let waterLitersPerAcre = 0;
    let recommendation = "";

    if (moisture < soilInfo.pwp + 5) {
      // Wilting point reached
      if (isRainImminent) {
        irrigationStatus = "DELAYED (RAIN PENDING)";
        recommendation = `Soil moisture (${moisture}%) is near wilting point, but **${rainForecast}% rain is forecasted within 6h**. Delay pump activation by 3 hours and re-assess to avoid over-irrigation.`;
      } else {
        irrigationStatus = "CRITICAL IRRIGATION REQUIRED";
        // Calculate volume: Deficit % * Root Depth * 10 * Crop Factor (Liters/acre)
        waterLitersPerAcre = Math.round(moistureDeficit * soilInfo.rootDepthMm * 0.15 * cropInfo.waterFactor * 40);
        pumpMinutes = Math.round(waterLitersPerAcre / 45); // assuming 45 L/min drip discharge
        recommendation = `Soil is severely dry. Immediate irrigation required. Run drip system for **${pumpMinutes} minutes** (${waterLitersPerAcre.toLocaleString()} L/acre).`;
      }
    } else if (moisture < targetMoisture) {
      if (isRainImminent) {
        irrigationStatus = "DELAYED (RAIN PENDING)";
        recommendation = `Moisture is slightly below target (${moisture}% < ${targetMoisture}%), but imminent rainfall (${rainForecast}%) will replenish root zone naturally. **HOLD IRRIGATION**.`;
      } else {
        irrigationStatus = "LIGHT IRRIGATION RECOMMENDED";
        waterLitersPerAcre = Math.round(moistureDeficit * soilInfo.rootDepthMm * 0.08 * cropInfo.waterFactor * 40);
        pumpMinutes = Math.round(waterLitersPerAcre / 45);
        recommendation = `Moisture deficit detected. Recommended precision top-up of **${pumpMinutes} minutes** (${waterLitersPerAcre.toLocaleString()} L/acre).`;
      }
    } else {
      irrigationStatus = "SOIL MOISTURE OPTIMAL";
      recommendation = `Soil moisture (${moisture}%) is currently optimal for ${crop} during ${stage} stage. Relay stays OFF. Nutrients preserved in root zone.`;
    }

    // 4. Disease Predisposition Index (Temp + Humidity)
    let diseaseRisk = "LOW (Safe Canopy)";
    let diseaseAdvice = "Microclimate is well-ventilated with minimal fungal sporulation risk.";
    let diseaseRiskColor = "text-emerald-400";

    if (humidity >= 78 && temp >= 22 && temp <= 32) {
      diseaseRisk = "CRITICAL (Fungal Outbreak Alert)";
      diseaseRiskColor = "text-red-400";
      diseaseAdvice = `High relative humidity (${humidity}%) and warm canopy temp (${temp}°C) create ideal incubation conditions for Blight, Powdery Mildew, and Anthracnose. Spray preventive bio-fungicide (*Trichoderma viride* 5g/L).`;
    } else if (humidity >= 65 && temp >= 20) {
      diseaseRisk = "MODERATE (Monitor Leaves)";
      diseaseRiskColor = "text-amber-400";
      diseaseAdvice = "Moderate fungal risk. Inspect lower canopy leaves for initial chlorotic spots.";
    }

    // 5. Fertilizer Retention & Leaching Hazard
    let leachingHazard = "SAFE (Nutrients Intact in Root Zone)";
    let leachingColor = "text-emerald-400";
    if (moisture > soilInfo.fc + 5) {
      leachingHazard = "HIGH RISK (Active Nitrate Leaching Detected)";
      leachingColor = "text-red-400";
    }

    return {
      moisture,
      temp,
      humidity,
      vpd,
      vpdStatus,
      vpdColor,
      irrigationStatus,
      pumpMinutes,
      waterLitersPerAcre,
      recommendation,
      diseaseRisk,
      diseaseRiskColor,
      diseaseAdvice,
      leachingHazard,
      leachingColor,
      crop,
      stage,
      soilType
    };
  }

  initChart(canvasId) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    const now = new Date();
    
    for (let i = 9; i >= 0; i--) {
      const t = new Date(now.getTime() - i * 3000);
      this.history.labels.push(t.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
      this.history.moisture.push(this.soilMoisture + (Math.random() - 0.5) * 1.5);
      this.history.temp.push(this.ambientTemp + (Math.random() - 0.5) * 0.8);
      this.history.vpd.push(this.vpd + (Math.random() - 0.5) * 0.1);
    }

    this.chart = new Chart(ctx, {
      type: 'line',
      data: {
        labels: this.history.labels,
        datasets: [
          {
            label: 'Soil Moisture (%)',
            data: this.history.moisture,
            borderColor: '#38bdf8',
            backgroundColor: 'rgba(56, 189, 248, 0.1)',
            fill: true,
            tension: 0.35,
            yAxisID: 'y'
          },
          {
            label: 'Ambient Temp (°C)',
            data: this.history.temp,
            borderColor: '#f59e0b',
            borderDash: [4, 4],
            tension: 0.35,
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        animation: { duration: 400 },
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: { labels: { color: '#94a3b8', font: { size: 11 } } },
          tooltip: { backgroundColor: '#0f172a', borderColor: '#334155', borderWidth: 1 }
        },
        scales: {
          x: { ticks: { color: '#64748b', maxTicksLimit: 6 }, grid: { color: '#1e293b' } },
          y: {
            min: 0,
            max: 100,
            ticks: { color: '#38bdf8' },
            grid: { color: '#1e293b' },
            title: { display: true, text: 'Moisture %', color: '#38bdf8' }
          },
          y1: {
            position: 'right',
            min: 15,
            max: 50,
            ticks: { color: '#f59e0b' },
            grid: { drawOnChartArea: false },
            title: { display: true, text: 'Temp °C', color: '#f59e0b' }
          }
        }
      }
    });

    this.startTelemetryLoop();
  }

  startTelemetryLoop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => this.tick(), 3000);
  }

  tick() {
    const es = 0.61078 * Math.exp((17.27 * this.ambientTemp) / (this.ambientTemp + 237.3));
    const ea = es * (this.humidity / 100);
    this.vpd = Math.max(0.1, parseFloat((es - ea).toFixed(2)));

    const rainImminent = window.weatherEngine && window.weatherEngine.weatherData && window.weatherEngine.weatherData.isRainImminent;
    const rainProb = window.weatherEngine && window.weatherEngine.weatherData ? window.weatherEngine.weatherData.rainProb6h : 60;

    if (this.soilMoisture < this.customThreshold) {
      if (rainImminent) {
        this.pumpState = "DELAYED";
        this.pumpReason = `Predictive Hold: ${rainProb}% rain forecasted within 6h. Delaying irrigation to save water and prevent fertilizer leaching.`;
        this.stats.waterSavedLiters += 35;
        this.stats.fertilizerSavedKg = parseFloat((this.stats.fertilizerSavedKg + 0.12).toFixed(1));
      } else {
        this.pumpState = "ACTIVE";
        this.pumpReason = `Soil moisture (${this.soilMoisture.toFixed(1)}%) is below calibrated threshold (${this.customThreshold}%). ESP32 Relay closed, pump running.`;
        this.pumpActiveSeconds += 3;
        this.soilMoisture = Math.min(100, this.soilMoisture + 1.8);
      }
    } else {
      this.pumpState = "IDLE";
      this.pumpReason = `Target moisture achieved (${this.soilMoisture.toFixed(1)}% >= ${this.customThreshold}%). ESP32 Relay open, pump stopped.`;
      this.soilMoisture = Math.max(5, this.soilMoisture - 0.25);
    }

    const timeStr = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    this.history.labels.push(timeStr);
    this.history.moisture.push(parseFloat(this.soilMoisture.toFixed(1)));
    this.history.temp.push(parseFloat(this.ambientTemp.toFixed(1)));
    this.history.vpd.push(this.vpd);

    if (this.history.labels.length > 15) {
      this.history.labels.shift();
      this.history.moisture.shift();
      this.history.temp.shift();
      this.history.vpd.shift();
    }

    if (this.chart) {
      this.chart.update('none');
    }

    this.renderUI();
  }

  renderUI() {
    const moistureVal = document.getElementById('valMoisture');
    const tempVal = document.getElementById('valTemp');
    const humidityVal = document.getElementById('valHumidity');
    const vpdVal = document.getElementById('valVpd');

    if (moistureVal) moistureVal.textContent = `${this.soilMoisture.toFixed(1)}%`;
    if (tempVal) tempVal.textContent = `${this.ambientTemp.toFixed(1)}°C`;
    if (humidityVal) humidityVal.textContent = `${this.humidity}%`;
    if (vpdVal) vpdVal.textContent = `${this.vpd} kPa`;

    const moistureBar = document.getElementById('barMoisture');
    if (moistureBar) moistureBar.style.width = `${Math.min(100, this.soilMoisture)}%`;

    const pumpBadge = document.getElementById('badgePumpStatus');
    const relayLed = document.getElementById('relayLed');
    const pumpReasonEl = document.getElementById('pumpReasonText');

    if (pumpBadge && relayLed) {
      if (this.pumpState === "ACTIVE") {
        pumpBadge.textContent = "PUMP ON (Irrigating)";
        pumpBadge.className = "px-3 py-1 text-xs font-bold rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500 animate-pulse";
        relayLed.className = "w-3 h-3 rounded-full bg-emerald-400 shadow-[0_0_12px_#34d399]";
      } else if (this.pumpState === "DELAYED") {
        pumpBadge.textContent = "IRRIGATION DELAYED (Rain Imminent)";
        pumpBadge.className = "px-3 py-1 text-xs font-bold rounded-full bg-amber-500/20 text-amber-300 border border-amber-500";
        relayLed.className = "w-3 h-3 rounded-full bg-amber-400 shadow-[0_0_12px_#fbbf24]";
      } else {
        pumpBadge.textContent = "PUMP OFF (Standby)";
        pumpBadge.className = "px-3 py-1 text-xs font-bold rounded-full bg-slate-700 text-slate-300 border border-slate-600";
        relayLed.className = "w-3 h-3 rounded-full bg-slate-600";
      }
    }

    if (pumpReasonEl) {
      pumpReasonEl.textContent = this.pumpReason;
    }

    const waterSavedEl = document.getElementById('statWaterSaved');
    const energySavedEl = document.getElementById('statEnergySaved');
    const fertSavedEl = document.getElementById('statFertSaved');

    if (waterSavedEl) waterSavedEl.textContent = `${this.stats.waterSavedLiters} L`;
    if (energySavedEl) energySavedEl.textContent = `${this.stats.energySavedWh} Wh`;
    if (fertSavedEl) fertSavedEl.textContent = `${this.stats.fertilizerSavedKg} kg`;
  }
}

window.telemetryEngine = new TelemetryEngine();
