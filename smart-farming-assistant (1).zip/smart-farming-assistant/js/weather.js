// Weather Intelligence, Global Geocoding, 6-Hour Trajectory & Live GPS Engine
class WeatherEngine {
  constructor() {
    this.currentCity = "Ludhiana, Punjab, India";
    this.lat = 30.9010;
    this.lon = 75.8573;
    this.weatherData = null;
    this.isFetching = false;
    this.anomalies = [];
    this.searchResults = [];

    // Popular Quick Indian Agricultural Presets
    this.popularPresets = [
      { name: "Ludhiana, Punjab", lat: 30.9010, lon: 75.8573, state: "Punjab", country: "India" },
      { name: "Nashik, Maharashtra", lat: 19.9975, lon: 73.7898, state: "Maharashtra", country: "India" },
      { name: "Guntur, Andhra Pradesh", lat: 16.3067, lon: 80.4365, state: "Andhra Pradesh", country: "India" },
      { name: "Varanasi, Uttar Pradesh", lat: 25.3176, lon: 82.9739, state: "Uttar Pradesh", country: "India" },
      { name: "Thanjavur, Tamil Nadu", lat: 10.7870, lon: 79.1378, state: "Tamil Nadu", country: "India" },
      { name: "Baramati, Maharashtra", lat: 18.1517, lon: 74.5772, state: "Maharashtra", country: "India" },
      { name: "Amritsar, Punjab", lat: 31.6340, lon: 74.8723, state: "Punjab", country: "India" },
      { name: "Karnal, Haryana", lat: 29.6857, lon: 76.9905, state: "Haryana", country: "India" },
      { name: "Indore, Madhya Pradesh", lat: 22.7196, lon: 75.8577, state: "Madhya Pradesh", country: "India" },
      { name: "Coimbatore, Tamil Nadu", lat: 11.0168, lon: 76.9558, state: "Tamil Nadu", country: "India" },
      { name: "Rajkot, Gujarat", lat: 22.3039, lon: 70.8022, state: "Gujarat", country: "India" }
    ];
  }

  // 1. Live Browser GPS Location with Reverse Geocoding
  async detectUserGpsLocation() {
    return new Promise((resolve) => {
      if (!('geolocation' in navigator)) {
        alert("GPS Geolocation is not supported by your browser.");
        resolve(false);
        return;
      }

      navigator.geolocation.getCurrentPosition(
        async (position) => {
          this.lat = position.coords.latitude;
          this.lon = position.coords.longitude;
          
          // Reverse geocode to get actual district/town name
          const locationName = await this.reverseGeocode(this.lat, this.lon);
          this.currentCity = locationName;
          
          await this.fetchForecastByCoords(this.lat, this.lon, this.currentCity);
          resolve(true);
        },
        async (error) => {
          console.warn("GPS lookup denied or unavailable. Falling back to IP/Preset location.", error);
          alert("Location access was denied or timed out. You can type any city, district, or village in the search bar above!");
          resolve(false);
        },
        { timeout: 10000, enableHighAccuracy: true }
      );
    });
  }

  // 2. Reverse Geocoding using free OpenStreetMap Nominatim / BigDataCloud
  async reverseGeocode(lat, lon) {
    try {
      const url = `https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=${lat}&longitude=${lon}&localityLanguage=en`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        const locality = data.locality || data.city || data.principalSubdivision || "Field Location";
        const state = data.principalSubdivision || "";
        const country = data.countryName || "";
        return `📍 ${locality}${state ? ', ' + state : ''}${country ? ', ' + country : ''}`;
      }
    } catch (e) {
      console.warn("Reverse geocode failed, using coordinates:", e);
    }
    return `📍 Live Farm (${lat.toFixed(3)}°N, ${lon.toFixed(3)}°E)`;
  }

  // 3. Live Geocoding Search: Search ANY city, village, taluk, or district in the world in real time
  async searchAnyLocation(query) {
    if (!query || query.trim().length < 2) {
      this.searchResults = [];
      return [];
    }

    try {
      const cleanQuery = encodeURIComponent(query.trim());
      // Open-Meteo Global Geocoding API (Fast, Free, No API key required)
      const url = `https://geocoding-api.open-meteo.com/v1/search?name=${cleanQuery}&count=8&language=en&format=json`;
      const res = await fetch(url);
      if (!res.ok) throw new Error("Geocoding search error");
      const data = await res.json();

      if (data.results && data.results.length > 0) {
        this.searchResults = data.results.map(item => ({
          name: item.name,
          admin1: item.admin1 || "",
          country: item.country || "",
          lat: item.latitude,
          lon: item.longitude,
          displayName: `${item.name}${item.admin1 ? ', ' + item.admin1 : ''}${item.country ? ' (' + item.country + ')' : ''}`
        }));
        return this.searchResults;
      }
    } catch (err) {
      console.warn("Live geocoding search error:", err);
    }

    // Filter from local presets if offline
    this.searchResults = this.popularPresets
      .filter(p => p.name.toLowerCase().includes(query.toLowerCase()) || p.state.toLowerCase().includes(query.toLowerCase()))
      .map(p => ({
        name: p.name,
        admin1: p.state,
        country: p.country,
        lat: p.lat,
        lon: p.lon,
        displayName: `${p.name}, ${p.country}`
      }));

    return this.searchResults;
  }

  // 4. Fetch Weather by Exact Coordinates
  async fetchForecastByCoords(lat, lon, displayName) {
    this.isFetching = true;
    this.currentCity = displayName;
    this.lat = lat;
    this.lon = lon;

    try {
      const url = `https://api.open-meteo.com/v1/forecast?latitude=${this.lat}&longitude=${this.lon}&current=temperature_2m,relative_humidity_2m,apparent_temperature,precipitation,rain,weather_code,wind_speed_10m,wind_gusts_10m&hourly=temperature_2m,relative_humidity_2m,precipitation_probability,rain,weather_code,wind_speed_10m,soil_temperature_0cm&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max&timezone=auto`;
      
      const response = await fetch(url);
      if (!response.ok) throw new Error("Weather API unreachable");
      const data = await response.json();
      
      this.weatherData = this.processForecast(data);
      this.detectAnomalies(this.weatherData);
      this.isFetching = false;
      return this.weatherData;
    } catch (err) {
      console.warn("Using offline simulated weather engine:", err);
      this.weatherData = this.getSimulatedData(displayName);
      this.detectAnomalies(this.weatherData);
      this.isFetching = false;
      return this.weatherData;
    }
  }

  async fetchForecast(cityName = this.currentCity) {
    const preset = this.popularPresets.find(p => p.name === cityName);
    if (preset) {
      return this.fetchForecastByCoords(preset.lat, preset.lon, preset.name);
    }
    return this.fetchForecastByCoords(this.lat, this.lon, cityName);
  }

  processForecast(apiData) {
    const current = apiData.current;
    const hourly = apiData.hourly;
    const daily = apiData.daily;

    // 6-Hour Slices (0-6h, 6-12h, 12-18h, 24h, 30h, 36h)
    const sixHourForecasts = [];
    for (let slice = 0; slice < 6; slice++) {
      const startIdx = slice * 6;
      const endIdx = startIdx + 6;
      
      const temps = hourly.temperature_2m.slice(startIdx, endIdx);
      const rainProbs = hourly.precipitation_probability.slice(startIdx, endIdx);
      const rainSums = hourly.rain.slice(startIdx, endIdx);
      const humidities = hourly.relative_humidity_2m.slice(startIdx, endIdx);
      const winds = hourly.wind_speed_10m.slice(startIdx, endIdx);

      const maxTemp = Math.max(...temps);
      const minTemp = Math.min(...temps);
      const maxRainProb = Math.max(...rainProbs);
      const totalRainMm = rainSums.reduce((a, b) => a + b, 0);
      const avgHum = Math.round(humidities.reduce((a, b) => a + b, 0) / humidities.length);
      const maxWind = Math.max(...winds);

      const startTimeStr = new Date(hourly.time[startIdx]).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
      const endTimeStr = new Date(hourly.time[endIdx - 1]).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

      sixHourForecasts.push({
        intervalLabel: `+${slice * 6}h to +${(slice + 1) * 6}h`,
        timeRange: `${startTimeStr} - ${endTimeStr}`,
        maxTemp: Math.round(maxTemp),
        minTemp: Math.round(minTemp),
        maxRainProb: maxRainProb,
        totalRainMm: totalRainMm.toFixed(1),
        avgHumidity: avgHum,
        maxWindSpeed: Math.round(maxWind),
        isRainy: maxRainProb >= 50 || totalRainMm >= 2.0
      });
    }

    const next6hProb = hourly.precipitation_probability.slice(0, 6);
    const max6hRainProb = Math.max(...next6hProb, 0);
    const sum6hRain = hourly.rain.slice(0, 6).reduce((a, b) => a + b, 0);
    const condition = this.interpretWeatherCode(current.weather_code);

    return {
      cityName: this.currentCity,
      temp: Math.round(current.temperature_2m),
      humidity: Math.round(current.relative_humidity_2m),
      windSpeed: Math.round(current.wind_speed_10m),
      currentPrecip: current.precipitation,
      conditionText: condition.text,
      conditionIcon: condition.icon,
      rainProb6h: max6hRainProb,
      rainSum6h: sum6hRain.toFixed(1),
      dailyMax: Math.round(daily.temperature_2m_max[0]),
      dailyMin: Math.round(daily.temperature_2m_min[0]),
      dailyProb: daily.precipitation_probability_max[0] || 0,
      sixHourSlices: sixHourForecasts,
      isRainImminent: max6hRainProb >= 50 || sum6hRain >= 2.0
    };
  }

  detectAnomalies(data) {
    this.anomalies = [];
    if (!data) return;

    if (data.dailyMax >= 40 || data.temp >= 39) {
      this.anomalies.push({
        type: "heatwave",
        level: "CRITICAL",
        title: "🔥 Severe Heatwave Warning (> 40°C)",
        desc: "Extreme thermal radiation detected. Stomatal conductance will shut down, increasing heat scorch risk. Apply Kaolin clay foliar barrier and irrigate only in early dawn.",
        badgeClass: "bg-red-950 text-red-300 border-red-700"
      });
    }

    if (parseFloat(data.rainSum6h) >= 15.0 || data.sixHourSlices.some(s => parseFloat(s.totalRainMm) >= 20.0)) {
      this.anomalies.push({
        type: "heavy_rain",
        level: "CRITICAL",
        title: "🌊 Heavy Downpour & Waterlogging Alert",
        desc: "Excessive rainfall (> 15-20 mm) expected. Halt all irrigation immediately, clear field drainage channels, and delay chemical fertilization to prevent total leaching.",
        badgeClass: "bg-sky-950 text-sky-300 border-sky-700"
      });
    }

    if (data.humidity >= 80 && data.temp >= 22 && data.temp <= 31) {
      this.anomalies.push({
        type: "fungal_risk",
        level: "HIGH WARNING",
        title: "🍄 Fungal Disease Epidemic Trigger (High RH)",
        desc: "Air humidity is above 80% with warm ambient canopy temperatures. Ideal microclimate for Late Blight, Anthracnose, and Downy Mildew spores. Spray prophylactic bio-fungicide.",
        badgeClass: "bg-amber-950 text-amber-300 border-amber-700"
      });
    }

    if (data.windSpeed >= 32 || data.sixHourSlices.some(s => s.maxWindSpeed >= 35)) {
      this.anomalies.push({
        type: "wind_storm",
        level: "MODERATE ALERT",
        title: "💨 High Wind / Crop Lodging Threat (> 35 km/h)",
        desc: "Gusty winds increase lodging risk in tall crops (Sugarcane, Maize). Postpone foliar spraying to avoid chemical spray drift into non-target zones.",
        badgeClass: "bg-purple-950 text-purple-300 border-purple-700"
      });
    }

    if (this.anomalies.length === 0) {
      this.anomalies.push({
        type: "safe",
        level: "NORMAL",
        title: "✅ Stable Agro-Microclimate",
        desc: "No extreme weather anomalies detected in the next 36 hours. Normal IoT smart irrigation protocol active.",
        badgeClass: "bg-emerald-950 text-emerald-300 border-emerald-700"
      });
    }
  }

  interpretWeatherCode(code) {
    if (code === 0) return { text: "Clear Sunny Sky", icon: "sun" };
    if (code <= 3) return { text: "Partly Cloudy", icon: "cloud-sun" };
    if (code >= 51 && code <= 67) return { text: "Light Rain / Drizzle", icon: "cloud-drizzle" };
    if (code >= 80 && code <= 82) return { text: "Rain Showers", icon: "cloud-rain" };
    if (code >= 95) return { text: "Thunderstorm Warning", icon: "cloud-lightning" };
    return { text: "Overcast Clouds", icon: "cloud" };
  }

  getSimulatedData(cityName) {
    return {
      cityName: cityName,
      temp: 34,
      humidity: 82,
      windSpeed: 14,
      currentPrecip: 0,
      conditionText: "Partly Cloudy (Simulated)",
      conditionIcon: "cloud-sun",
      rainProb6h: 70,
      rainSum6h: "6.2",
      dailyMax: 36,
      dailyMin: 25,
      dailyProb: 75,
      sixHourSlices: [
        { intervalLabel: "+0h to +6h", timeRange: "02:00 PM - 08:00 PM", maxTemp: 34, minTemp: 29, maxRainProb: 70, totalRainMm: "6.2", avgHumidity: 82, maxWindSpeed: 14, isRainy: true },
        { intervalLabel: "+6h to +12h", timeRange: "08:00 PM - 02:00 AM", maxTemp: 28, minTemp: 25, maxRainProb: 65, totalRainMm: "4.8", avgHumidity: 88, maxWindSpeed: 11, isRainy: true },
        { intervalLabel: "+12h to +18h", timeRange: "02:00 AM - 08:00 AM", maxTemp: 26, minTemp: 24, maxRainProb: 30, totalRainMm: "0.5", avgHumidity: 90, maxWindSpeed: 8, isRainy: false },
        { intervalLabel: "+18h to +24h", timeRange: "08:00 AM - 02:00 PM", maxTemp: 33, minTemp: 27, maxRainProb: 15, totalRainMm: "0.0", avgHumidity: 65, maxWindSpeed: 12, isRainy: false },
        { intervalLabel: "+24h to +30h", timeRange: "02:00 PM - 08:00 PM", maxTemp: 35, minTemp: 30, maxRainProb: 20, totalRainMm: "0.0", avgHumidity: 58, maxWindSpeed: 16, isRainy: false },
        { intervalLabel: "+30h to +36h", timeRange: "08:00 PM - 02:00 AM", maxTemp: 29, minTemp: 26, maxRainProb: 25, totalRainMm: "0.2", avgHumidity: 70, maxWindSpeed: 10, isRainy: false }
      ],
      isRainImminent: true
    };
  }
}

window.weatherEngine = new WeatherEngine();
